package Server.ChatRoom;

import java.io.*;
import java.util.*;

import Server.ClientConnection.ClientConnection;
import Server.Tool.CrazyitMap;

public class LocalChatRoom extends ChatRoom {
	/*---------------------------------------------------------------*/
	private String owner;
	private CrazyitMap<String, ClientConnection> members;

	/*---------------------------------------------------------------*/
	public LocalChatRoom(String roomid, String owner) {
		super(roomid);
		this.owner = owner;
		this.members = new CrazyitMap<String, ClientConnection>();
	}

	/*---------------------------------------------------------------*/
	public String getOwner() {
		return owner;
	}

	/*---------------------------------------------------------------*/
	public CrazyitMap<String, ClientConnection> getAll_Members() {
		return this.members;
	}

	/*---------------------------------------------------------------*/
	public Set<String> getAll_MembersName() {
		return this.members.map.keySet();
	}

	/*---------------------------------------------------------------*/
	public Set<ClientConnection> getAll_ClientThreads() {
		return this.members.valueSet();
	}

	/*---------------------------------------------------------------*/
	public void addMemeber(String client_id, ClientConnection cc) {
		members.put(client_id, cc);
	}

	/*---------------------------------------------------------------*/
	public void removeMember(String member) {
		members.map.remove(member);
	}

	/*---------------------------------------------------------------*/
	public void boardCastAll(String msg) throws IOException {

		Set<ClientConnection> all_cc = members.valueSet();
		// 用lambda表达式代替遍历：
		all_cc.forEach(cc -> cc.write(msg));
	}

	/*---------------------------------------------------------------*/
}
