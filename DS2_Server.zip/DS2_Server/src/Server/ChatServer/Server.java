package Server.ChatServer;

import java.net.*; 
import java.util.ArrayList;
import java.util.Scanner;
//kailiadd
import java.io.*;

import Server.ChatRoom.RemoteChatRoom;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.kohsuke.args4j.CmdLineException;
import org.kohsuke.args4j.CmdLineParser;
import Server.Tool.CrazyitMap;
import Server.Tool.JsonOperation;
import Server.Tool.CmdLineArgs;

import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLServerSocketFactory;
import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

public class Server {
	// -h localhost -p 4444 -i Adel
	// -n s1 -l configuration.txt

	// -------------------------kaili
	static PrintWriter OutputStream = null;
	public static String path;
	public static ServerInfo thisServer;
	public static String server_id;
	public static ServerDef this_serverDef;
	// -------------kailil


	public static CrazyitMap<String, ServerInfo> all_ServerInfo = new CrazyitMap<>();
	public static ArrayList<ServerInfo> allServer = new ArrayList<ServerInfo>();
	private static int client_SocketPort = 0;
	private static int server_SocketPort = 0;

	/*---------------------------------------------------------------*/
	public static void main(String[] args) throws IOException {

		int otherserver_count = 0;
		int Fileline = 0;

		System.setProperty("javax.net.ssl.keyStore", "mykeystore");
		// Password to access the private key from the keystore file
		System.setProperty("javax.net.ssl.keyStorePassword", "123456");

		// Enable debugging to view the handshake and communication which
		// happens between the SSLClient and the SSLServer
		// System.setProperty("javax.net.debug","all");

		System.setProperty("javax.net.ssl.trustStore", "mykeystore");

		SSLServerSocket listening_Socket = null;
		SSLServerSocket listening_ServerSocket = null;

		CmdLineArgs argsBean = new CmdLineArgs();
		CmdLineParser parser = new CmdLineParser(argsBean);
		try {
			parser.parseArgument(args);

		} catch (CmdLineException e) {
			System.err.println(e.getMessage());
			parser.printUsage(System.err);
		}
		server_id = argsBean.getServerid();
		path = argsBean.getserversconf();
		FileReader file = new FileReader(path);
		String line = null;

		try {
			BufferedReader reader = new BufferedReader(file);
			while ((line = reader.readLine()) != null) {
				String[] info = line.split("\t");

				String serverID = info[0];
				String serverAddress = info[1];
				int clientPort = Integer.valueOf(info[2]);
				int managementPort = Integer.valueOf(info[3]);
				
				/*---------------------------------------------------------------*/
				if (serverID.equals(server_id)) {
					thisServer = new ServerInfo(serverID, serverAddress, clientPort, managementPort, "on");
					client_SocketPort = thisServer.getClientPort();
					server_SocketPort = thisServer.getManagementPort();
					all_ServerInfo.put(serverID, thisServer);
					allServer.add(thisServer);
				} else {
					ServerInfo server = new ServerInfo(serverID, serverAddress, clientPort, managementPort,
							"off");
					all_ServerInfo.put(serverID, server);
					allServer.add(server);
					otherserver_count++;
				}
				Fileline++;
			}
			reader.close();

		} catch (Exception e) {
			e.printStackTrace();
		}

		if (otherserver_count == Fileline) {
			String[] key;
			Scanner keyboard = new Scanner(System.in);
			System.out.println("new server:");
			key = (keyboard.nextLine()).split(" ");
			String ServerID = key[0];
			String ServerAdd = key[1];
			int clientPort = Integer.valueOf(key[2]);
			int coordinatorPort = Integer.valueOf(key[3]);
			thisServer = new ServerInfo(ServerID, ServerAdd, clientPort, coordinatorPort, "on");
			client_SocketPort = thisServer.getClientPort();
			server_SocketPort = thisServer.getManagementPort();
			all_ServerInfo.put(ServerID, thisServer);
			allServer.add(thisServer);
		}

//		try {			
//			OutputStream = new PrintWriter(new FileOutputStream("configuration.txt"));
//		} catch (FileNotFoundException e) { // TODO Auto-generated catch
//											// block
//			e.printStackTrace();
//		}
//
//		for (int i = 0; i < allServer.size(); i++) {
//			OutputStream.println(allServer.get(i).getServerName() + "\t" + allServer.get(i).getAddress() + "\t"
//					+ allServer.get(i).getClientPort() + "\t" + allServer.get(i).getManagementPort() + "\t"
//					+ allServer.get(i).getServerstatus());
//		}
//		OutputStream.close();

		try {
			// Create a server socket listening on port
			SSLServerSocketFactory sslserversocketfactory = (SSLServerSocketFactory) SSLServerSocketFactory
					.getDefault();
			listening_Socket = (SSLServerSocket) sslserversocketfactory.createServerSocket(client_SocketPort);
			System.out.println(Thread.currentThread().getName() + " - Server " + server_id + " listening on port "
					+ client_SocketPort + " - for a ClientConnection");
			// Create a server socket listening on port
			listening_ServerSocket = (SSLServerSocket) sslserversocketfactory.createServerSocket(server_SocketPort);
			System.out.println(Thread.currentThread().getName() + " - Server " + server_id + " listening on port "
					+ server_SocketPort + " - for a ServerConnection");
			this_serverDef = new ServerDef(server_id);
			this_serverDef.getMainHall().setRoomId("MainHall-" + server_id);
			this_serverDef.addLocal_RoomList(this_serverDef.getMainHall().getRoomId(), this_serverDef.getMainHall());

			/*
			 * for (String remote_ServerId : all_ServerInfo.map.keySet()) { //
			 * if(isOn(remote_ServerId)){ if
			 * (!remote_ServerId.equals(server_id)) {
			 * this_serverDef.getRemote_RoomList().put("MainHall-" +
			 * remote_ServerId, new RemoteChatRoom("MainHall-" +
			 * remote_ServerId, remote_ServerId)); } }}
			 */
			ToClientThread client_Connection = new ToClientThread(listening_Socket, this_serverDef, 0);
			Thread toClientThread = new Thread(client_Connection, "toClientThread");
			toClientThread.start();

			ToServerThread server_Connection = new ToServerThread(listening_ServerSocket, this_serverDef, 0);
			Thread ToServerThread = new Thread(server_Connection, "ToServerThread");
			ToServerThread.start();
			
//			heartbeat heartbeatConnection = new heartbeat(5000,thisServer.getServerName());
//			Thread ToheartbeatThread = new Thread(heartbeatConnection,"ToHeartbeatThread");
//			ToheartbeatThread.start();
			
			System.out.println();
			System.out.println(Thread.currentThread().getName() + " - toClientThread is started ");
			System.out.println(Thread.currentThread().getName() + " - toServerThread is started ");
			System.out.println();
//
//			FileReader file1 = new FileReader(path);
//		all_ServerInfo.map.clear();
//		try {
//			int activeserver = 0;
//			BufferedReader reader = new BufferedReader(file1);
//		while ((line = reader.readLine()) != null) {
//				String[] info = line.split("\t");
//				String serverID = info[0];
//					String serverAddress = info[1];
//					int clientPort = Integer.valueOf(info[2]);
//					int managementPort = Integer.valueOf(info[3]);
//					String ServerStatus = info[4];
//					/*---------------------------------------------------------------*/
//					ServerInfo server = new ServerInfo(serverID, serverAddress, clientPort, managementPort,
//							ServerStatus);
//					activeserver++;
//					Server.all_ServerInfo.put(serverID, server);
//				}
//
//				reader.close();
//
//			} catch (Exception e) {
//				e.printStackTrace();
//			}

		//	for (String id : all_ServerInfo.map.keySet()) {
		  // System.out.println(id);
		   //System.out.println(all_ServerInfo.map.get(id).getServerstatus());
		
	//		}
			heartbeat hhh=new heartbeat(Server.thisServer.getServerName(),this_serverDef);
			//	Thread ToheartbeatThread = new Thread(hhh,"ToHeartbeatThread");
				//ToheartbeatThread.start();
				hhh.abc();
			
			int countyy = 0;
			for (String id : all_ServerInfo.map.keySet()) {
				countyy++;
				if ((!id.equals(this_serverDef.getServerId())) && isOn(id)) {
					System.out.println(countyy + " " + id);
					JSONParser pars = new JSONParser();
					JsonOperation jsonDo = new JsonOperation();
					ServerInfo server = Server.all_ServerInfo.map.get(id);
					String sMsg = jsonDo.newServer(thisServer.getServerName(),thisServer.getAddress(),thisServer.getClientPort(),thisServer.getManagementPort());
					BufferedReader sReader = writeToServer(server, sMsg);
					String serverMsg = null;
					int count = 0;
					ArrayList<String> roomlist = new ArrayList<>();
					 serverMsg = sReader.readLine();
					 System.out.println(serverMsg);
						JSONObject message = (JSONObject) pars.parse(serverMsg);
						String type = (String) message.get("type");
						if (type.equals("roomlist")) {
							String currentserver = (String) message.get("serverid");
							JSONArray array = (JSONArray) message.get("rooms");
							for (int i = 0; i < array.size(); i++) {
								this_serverDef.getRemote_RoomList().put((String) array.get(i),
										new RemoteChatRoom((String) array.get(i), currentserver));
							}
						}
				}
			}
System.out.println("tt");
			while(true){
				Thread.sleep(2000);
				heartbeat hhh1=new heartbeat(Server.thisServer.getServerName(),this_serverDef);
			//	Thread ToheartbeatThread = new Thread(hhh,"ToHeartbeatThread");
				//ToheartbeatThread.start();
				hhh1.abc();
			}
		
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static boolean isOn(String id) {
		if (all_ServerInfo.map.get(id).getServerstatus().equals("on")) {
//			System.out.println("true");
			return true;
		}
		return false;
	}

	public static BufferedReader writeToServer(ServerInfo server, String sMsg) throws IOException {
		SSLSocketFactory sslsocketfactory = (SSLSocketFactory) SSLSocketFactory.getDefault();
		SSLSocket serverSocket = (SSLSocket) sslsocketfactory.createSocket(server.getAddress(),
				server.getManagementPort());

		BufferedReader sReader = getSreader(serverSocket);
		BufferedWriter sWriter = getSwriter(serverSocket);

		sWriter.write(sMsg + "\n");
		sWriter.flush();
		return sReader;
	}

	public static BufferedReader getSreader(SSLSocket socket) throws IOException {
		BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream(), "UTF-8"));
		return reader;
	}
	//s7 localhost 9999 6666

	/*---------------------------------------------------------------*/
	public static BufferedWriter getSwriter(SSLSocket socket) throws IOException {
		BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream(), "UTF-8"));
		return writer;
	}

}
