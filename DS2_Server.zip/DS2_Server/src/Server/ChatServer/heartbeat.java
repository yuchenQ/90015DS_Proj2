package Server.ChatServer;

import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Date;
import java.util.concurrent.BlockingQueue;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;

import org.json.simple.JSONObject;

import Server.ChatRoom.LocalChatRoom;
import Server.ChatRoom.RemoteChatRoom;
import Server.Message.Message;
import Server.Tool.CrazyitMap;
import Server.Tool.JsonOperation;

public class heartbeat {
	protected BufferedWriter writer;
	protected ServerDef serverDef;
	protected JsonOperation jsonDo;
	protected BlockingQueue<Message> messageQueue;
	private int Interval;
	private String server_id;
	SSLSocket socketht;
	// public heartbeat(int Interval, String server_id) {
	// try {
	// this.server_id = server_id;
	// Interval = 5000;
	// System.out.println("-- HeartbeatConnection " + " 寤虹珛浜� " + new Date());
	// } catch (Exception e) {
	// e.printStackTrace();
	// }
	// }

	public heartbeat(String server_id, ServerDef serverdef) {

		// TODO Auto-generated constructor stub
		try {
			this.server_id = server_id;
			this.serverDef = serverdef;
			// System.out.println("-- HeartbeatConnection " + " start at " + new
			// Date());

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/*---------------------------------------------------------------*/

	public void abc() {

		for (String id : Server.all_ServerInfo.map.keySet()) {
			if (!id.equals(server_id)) {

			
				try {

					SSLSocketFactory sslsocketfactory = (SSLSocketFactory) SSLSocketFactory.getDefault();
					SSLSocket socketht = (SSLSocket) sslsocketfactory.createSocket(
							Server.all_ServerInfo.map.get(id).getAddress(),
							Server.all_ServerInfo.map.get(id).getManagementPort());
					BufferedWriter writer = new BufferedWriter(
							new OutputStreamWriter(socketht.getOutputStream(), "UTF-8"));
					writer.write(heartbeatMsg().toJSONString() + "\n");
					writer.close();
					Server.all_ServerInfo.map.get(id).setServerstatus("on");
				} catch (IOException e) {
					// TODO Auto-generated catch block
					System.out.println("-----------------------------------------------------");
					System.out.println();
					System.out.println("server " + id + " crashed" + "socket closed" + e);
					System.out.println();
					System.out.println("-----------------------------------------------------");
					Server.all_ServerInfo.map.get(id).setServerstatus("off");

					CrazyitMap<String, RemoteChatRoom> roomlist = serverDef.getRemote_RoomList();
					for (RemoteChatRoom room : roomlist.valueSet()) {
						if (room.getServer().equals(id)) {
							serverDef.getRemote_RoomList().removeByValue(room);
						}
					}

//					PrintWriter OutputStream = null;
//					try {
//						OutputStream = new PrintWriter(new FileOutputStream("configuration.txt"));
//					} catch (FileNotFoundException e2) { // TODO Auto-generated
//															// catch
//															// block
//						e2.printStackTrace();
//					}
//					for (String newid : Server.all_ServerInfo.map.keySet()) {
//						OutputStream.println(Server.all_ServerInfo.map.get(newid).getServerName() + "\t"
//								+ Server.all_ServerInfo.map.get(newid).getAddress() + "\t"
//								+ Server.all_ServerInfo.map.get(newid).getClientPort() + "\t"
//								+ Server.all_ServerInfo.map.get(newid).getManagementPort() + "\t"
//								+ Server.all_ServerInfo.map.get(newid).getServerstatus());
//					}
//					OutputStream.close();
				}

				// Server.this_serverDef.removeRemoteRoombyServerid(server_id);
			}
		} // if
		// for
	}

	@SuppressWarnings("unchecked")
	public static JSONObject heartbeatMsg() {
		JSONObject hb = new JSONObject();
		hb.put("type", "Hello");
		return hb;
	}

}
