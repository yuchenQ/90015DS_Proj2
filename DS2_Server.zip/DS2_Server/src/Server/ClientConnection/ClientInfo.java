package Server.ClientConnection;

import Server.ChatRoom.LocalChatRoom;

public class ClientInfo {
	/*---------------------------------------------------------------*/
	private String id;
	private LocalChatRoom room;
	private ClientConnection cc;
	private boolean isOwner;

	/*---------------------------------------------------------------*/
	public ClientInfo(String id, LocalChatRoom room, ClientConnection cc, boolean isOwner) {
		this.id = id;
		this.room = room;
		this.cc = cc;
		this.isOwner = isOwner;
	}

	/*---------------------------------------------------------------*/
	public String getClient_id() {
		return id;
	}

	public void setClient_id(String id) {
		this.id = id;
	}

	/*---------------------------------------------------------------*/
	public LocalChatRoom getCurrentChatRoom() {
		return room;
	}

	public void setCurrentChatRoom(LocalChatRoom room) {
		this.room = room;
	}

	/*---------------------------------------------------------------*/
	public ClientConnection getCurrentCC() {
		return cc;
	}

	public void setCurrentCC(ClientConnection cc) {
		this.cc = cc;
	}

	/*---------------------------------------------------------------*/
	public boolean getIsOwner() {
		return isOwner;
	}

	public void setIsOwner(boolean isOwner) {
		this.isOwner = isOwner;
	}
	/*---------------------------------------------------------------*/
}
